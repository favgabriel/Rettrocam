package com.example.rettrocam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.List;

import be.teletask.onvif.OnvifManager;
import be.teletask.onvif.listeners.OnvifDeviceInformationListener;
import be.teletask.onvif.listeners.OnvifMediaProfilesListener;
import be.teletask.onvif.listeners.OnvifMediaStreamURIListener;
import be.teletask.onvif.listeners.OnvifResponseListener;
import be.teletask.onvif.listeners.OnvifServicesListener;
import be.teletask.onvif.models.OnvifDevice;
import be.teletask.onvif.models.OnvifDeviceInformation;
import be.teletask.onvif.models.OnvifMediaProfile;
import be.teletask.onvif.models.OnvifServices;

public class AddressActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address);

        final OnvifManager onvifManager = new OnvifManager();
        onvifManager.setOnvifResponseListener((OnvifResponseListener) this);
        final OnvifDevice device = new OnvifDevice("192.168.0.131");
        device.setPassword("username");
        device.setUsername("password");

        onvifManager.getServices(device, new OnvifServicesListener() {
            @Override
            public void onServicesReceived( OnvifDevice onvifDevice, OnvifServices services) {
                onvifManager.getDeviceInformation(device, new OnvifDeviceInformationListener() {
                    @Override
                    public void onDeviceInformationReceived( OnvifDevice device,
                                                             OnvifDeviceInformation deviceInformation) {
                        onvifManager.getMediaProfiles(device, new OnvifMediaProfilesListener() {
                            @Override
                            public void onMediaProfilesReceived( OnvifDevice device,
                                                                 List<OnvifMediaProfile> mediaProfiles) {
                                onvifManager.getMediaStreams(device, mediaProfiles.get(0), new OnvifMediaStreamURIListener() {
                                    @Override
                                    public void onMediaStreamURIReceived( OnvifDevice device,
                                                                          OnvifMediaProfile profile, String uri) {


                                    }
                                });
                            }
                        });
                    }
                });
            }
        });

    }


}
